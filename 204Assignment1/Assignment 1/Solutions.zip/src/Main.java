import org.knowm.xchart.*;
import org.knowm.xchart.style.Styler;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

class Main {
    public static void main(String[] args) throws IOException {

        Scanner file = new Scanner(new File(args[0]));
        String line = file.nextLine();

        int[] numbers = new int[251281];
        int index = 0;
        while (file.hasNext()) {
            line = file.nextLine();
            numbers[index++] = Integer.parseInt(line.split(",")[7]);
        }

        Function insertion = Sort::insertion_sort;
        Function merge = Sort::merge_sort;
        Function pigeonhole = Sort::pigeonhole_sort;
        Function count = Sort::counting_sort;

        double[][] result_count = Sort.try_sort(numbers, count, "Counting sorting");
        double[][] result_insertion = Sort.try_sort(numbers, insertion, "Insertion sorting");
        double[][] result_merge = Sort.try_sort(numbers, merge, "Merge sorting");
        double[][] result_pigeon = Sort.try_sort(numbers, pigeonhole, "Pigeonhole sorting");

        int[] xAxis = {512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 251282};

        double[][] yAxis_random = new double[4][10];
        double[][] yAxis_sorted = new double[4][10];
        double[][] yAxis_reversed = new double[4][10];

        yAxis_random[0] = result_count[0];
        yAxis_random[1] = result_insertion[0];
        yAxis_random[2] = result_merge[0];
        yAxis_random[3] = result_pigeon[0];

        yAxis_sorted[0] = result_count[1];
        yAxis_sorted[1] = result_insertion[1];
        yAxis_sorted[2] = result_merge[1];
        yAxis_sorted[3] = result_pigeon[1];

        yAxis_reversed[0] = result_count[2];
        yAxis_reversed[1] = result_insertion[2];
        yAxis_reversed[2] = result_merge[2];
        yAxis_reversed[3] = result_pigeon[2];


        showAndSaveChart("Random Data Test", xAxis, yAxis_random);
        showAndSaveChart("Sorted Data Test", xAxis, yAxis_sorted);
        showAndSaveChart("Reversed Data Test", xAxis, yAxis_reversed);
    }

    public static void showAndSaveChart(String title, int[] xAxis, double[][] yAxis) throws IOException {
        XYChart chart = new XYChartBuilder().width(800).height(600).title(title).yAxisTitle("Time in Milliseconds").xAxisTitle("Input Size").build();

        double[] doubleX = Arrays.stream(xAxis).asDoubleStream().toArray();

        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNE);
        chart.getStyler().setDefaultSeriesRenderStyle(XYSeries.XYSeriesRenderStyle.Line);

        chart.addSeries("Counting Sort", doubleX, yAxis[0]);
        chart.addSeries("Insertion Sort", doubleX, yAxis[1]);
        chart.addSeries("Merge Sort", doubleX, yAxis[2]);
        chart.addSeries("Pigeonhole Sort", doubleX, yAxis[3]);

        BitmapEncoder.saveBitmap(chart, title + ".png", BitmapEncoder.BitmapFormat.PNG);
    }
}
