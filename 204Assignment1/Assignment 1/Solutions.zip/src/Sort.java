import java.util.Arrays;

interface Function { void function(int[] array); }

public class Sort {

    public static void counting_sort(int[] array) {
        int N = array.length;
        int[] output = new int[N + 1];

        int max = array[0];
        for (int i = 1; i < N; i++) { if (array[i] > max) { max = array[i]; }}

        int[] count = new int[max + 1];
        for (int i = 0; i < max; ++i) { count[i] = 0; }
        for (int i = 0; i < N; i++) { count[array[i]]++; }
        for (int i = 1; i <= max; i++) { count[i] += count[i - 1]; }

        for (int i = N - 1; i >= 0; i--) {
            output[count[array[i]] - 1] = array[i];
            count[array[i]]--;
        }

        System.arraycopy(output, 0, array, 0, N);
    }

    public static void insertion_sort (int[] array) {
        for (int i = 1; i < array.length; ++i) {
            int key = array[i];
            int j = i-1;

            while (j >= 0 && array[j] > key) {
                array[j+1] = array[j];
                j -= 1;
            }

            array[j+1] = key;
        }
    }

    public static void merge_sort (int[] array) {
        mergesort(array, 0, array.length-1);
    }

    public static void mergesort(int[] array, int left, int right) {
        if (left < right) {
            int middle = left + (right - left)/2;
            mergesort(array, left, middle);
            mergesort(array, middle + 1, right);
            merge(array, left, middle, right);
        }
    }

    public static void merge(int[] array, int left, int middle, int right) {
        int number_1 = middle - left + 1;
        int number_2 = right - middle;
        int[] LEFT = new int[number_1];
        int[] RIGHT = new int[number_2];

        for (int i = 0; i < number_1; ++i) { LEFT[i] = array[left + i]; }
        for (int j = 0; j < number_2; ++j) { RIGHT[j] = array[middle + 1 + j]; }

        int i = 0, j = 0;
        int k = left;

        while (i < number_1 && j < number_2) {
            if (LEFT[i] <= RIGHT[j]) { array[k] = LEFT[i]; i++; }
            else { array[k] = RIGHT[j]; j++; }
            k++;
        }

        while (i < number_1) { array[k] = LEFT[i]; i++; k++; }
        while (j < number_2) { array[k] = RIGHT[j]; j++; k++; }
    }

    public static void pigeonhole_sort(int[] array) {
        int N = array.length;
        int minimum = array[0];
        int maximum = array[0];
        int range, i, j, index;

        for (int k : array) {
            if (k > maximum) { maximum = k; }
            if (k < minimum) { minimum = k; }
        }

        range = maximum - minimum + 1;
        int[] hole = new int[range];
        Arrays.fill(hole, 0);

        for(i = 0; i < N; i++) { hole[array[i] - minimum]++; }

        index = 0;
        for(j = 0; j < range; j++) {
            while(hole[j]-->0) { array[index++] = j + minimum; }
        }
    }

    public static double[][] try_sort (int[] numbers, Function function, String sort_name) {
        int index = -1;
        double[][] result = new double[3][10];

        for (int i = 512; i < 300000; i = i * 2) {
            if (i > 250000) { i = 251281; }
            int random_sort = 0;
            int sorted_sort = 0;
            int reverse_sort = 0;
            index++;
            int[] array = new int[i];
            int[] reverse_array = new int[i];

            for (int j = 0; j < 10; j++) {
                System.arraycopy(numbers, 0, array, 0, i);
                long start = System.currentTimeMillis();
                function.function(array);
                long end = System.currentTimeMillis();
                random_sort += end - start;
            }

            random_sort = random_sort / 10;
            System.out.println(sort_name + " with " + i + " random data takes an average of " + random_sort + " ms.");

            for (int k = 0; k < 10; k++) {
                long start = System.currentTimeMillis();
                function.function(array);
                long end = System.currentTimeMillis();
                sorted_sort += end - start;
            }

            sorted_sort = sorted_sort / 10;
            System.out.println(sort_name + " with " + i + " sorted data takes an average of " + sorted_sort + " ms.");

            int middle = i / 2;
            for (int l = 0; l < middle; l++) {
                int temp = array[l];
                array[l] = array[i-l-1];
                array[i-l-1] = temp;
            }

            for (int m = 0; m < 10; m++) {
                System.arraycopy(array, 0, reverse_array, 0, i);
                long start = System.currentTimeMillis();
                function.function(reverse_array);
                long end = System.currentTimeMillis();
                reverse_sort += end - start;
            }

            reverse_sort = reverse_sort / 10;
            System.out.println(sort_name + " with " + i + " reverse sorted data takes an average of " + reverse_sort + " ms.");

            result[0][index] = random_sort; result[1][index] = sorted_sort; result[2][index] = reverse_sort;
        } return result;
    }
}
